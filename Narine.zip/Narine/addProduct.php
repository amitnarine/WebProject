<?php
    include('database.php');

    $query='SELECT * FROM categories';

    $products=$db->query($query);

?>
<head>
<link rel="stylesheet" href="addProductCSS.css">

</head>

<header>
    <h2 id ="prod"> Product manager</h2>

</header>

<main>

    <h2 id="list">Add Product</h2>
    <form action="add.php" method="post">
    <label>Category:</label>
    <select name="category_id">
    <?php foreach($products as $product):?>
    <option value="<?php echo $product['categoryID']?>"> <?php echo $product['categoryName']?></option>
    <?php endforeach;?>
    </select><br>
    <label>Code:</label>
    <input type="text" name="code"><br>
    <label>Name:</label>
    <input type="text" name="name"><br>
    <label>List Price:</label>
    <input type="text" name="price"><br>
    <input id="button" type="submit" value="Add Product">
    </form>
    

    <h3><a id= "underlink"  href="productList.php">View Product List</a></h3>
    </main>
    <footer>
    <p id="bottom"> &copy; 2010 My Guitar Shop, Inc.</p>
    </footer>