<?php

    include('database.php');

    if (!isset($category)) {
    $category = filter_input(INPUT_GET, 'category_id',
                    FILTER_VALIDATE_INT);
    if ($category == NULL || $category == FALSE) {
            $category = 1;
    }
    }

    $query='SELECT * FROM categories';

    $items=$db->query($query);

    $query="SELECT * FROM products WHERE categoryID='$category'";

    $products=$db ->query($query);
?>

<head>
<link rel="stylesheet" href="categoryListCSS.css">
</head>
<header>
<h2 id="prod">Product Manager</h2>
        </header>

<h2 id = "list">Category List</h2>

<main>
        <table>
    <tr>
        <th>Name</th>
        <th></th>


    <?php foreach($items as $item):?>
        <tr>
        <td><?php echo $item['categoryName']?></td>
        <td><form action="deleteCat.php" method="post">
        <input type="hidden" name="category_id" value=<?php echo $item['categoryID']?>>
        <input id="del" type="submit" value="Delete">
        </form></td>
        </tr>
    <?php endforeach;?>
    </table>

    <h2 id="addcat">Add Category</h2>

    <form action="addCat.php" method="post">

    <label>Name:</label>
    <input id="text" type="text" name="name">
    <input id="sub" type="submit" value="Add">
    </form>

    <h3><a id= "underlink"  href="productList.php">List Products</a></h3>
    </main>
    <footer>
    
    <p id="bottom"> &copy; 2010 My Guitar Shop, Inc.</p>
    </footer>
    
