<?php

include('database.php');

if (isset($_POST['product_id'])) {
    $productID=$_POST['product_id'];





$query="DELETE FROM products WHERE productID='$productID'";
$db->exec($query);

include('productList.php');
} else {

include('productList.php');
}
?>
