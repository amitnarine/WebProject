<?php

include('database.php');
$categoryID=$_POST['category_id'];

$query="DELETE FROM products WHERE categoryID='$categoryID'";
$db->exec($query);

$query="DELETE FROM categories WHERE categoryID='$categoryID'";
$db->exec($query);

include('categoryList.php');

?>