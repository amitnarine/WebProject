<?php

    include('database.php');

    if (isset($_POST['category_id']) && isset($_POST['code']) && isset($_POST['name']) && isset($_POST['price'])) {



    $category=$_POST['category_id'];
    $code=$_POST['code'];
    $name=$_POST['name'];
    $price=$_POST['price'];

    $query="INSERT INTO products
        (categoryID, productCode, productName, listPrice) VALUES
        ('$category', '$code', '$name', '$price')";
    $db->exec($query);
    include('productList.php');
    } else {
        include('productList.php');
    }


?>