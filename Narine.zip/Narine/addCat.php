<?php

    include('database.php');

    $categoryName=$_POST['name'];

    $query="INSERT INTO categories
        (categoryName) VALUES
        ('$categoryName')";
    $db->exec($query);
    include('categoryList.php');


?>