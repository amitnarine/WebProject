<?php

    include('database.php');

    if (!isset($category)) {
    $category = filter_input(INPUT_GET, 'category_id',
                    FILTER_VALIDATE_INT);
    if ($category == NULL || $category == FALSE) {
            $category = 1;
    }
    }

    

    $query='SELECT * FROM categories';

    $items=$db->query($query);

    $query="SELECT * FROM products WHERE categoryID='$category'";

    $products=$db ->query($query);

    


?>

<head>
<link rel="stylesheet" href="productListCSS.css">
</head>

<header>
<h2 id="prod">Product Manager</h2>
        </header>

<h2 id = "list">Product List</h2>

<h4 id ="link"><a id="cat"  href="categoryList.php">Categories</a></h4>
<h4 id ="change"><?php echo $category ?></h4>



<aside>

    <ul>
    <?php foreach($items as $item) :?>
        <li><a id ="x" href="?category_id=<?php echo $item['categoryID']?>"><?php echo $item['categoryName']?></a></li>
    <?php endforeach; ?>
    </ul>
</aside>

<main>
    <table>
    <tr>
        <th>Code</th>
        <th>Name</th>
        <th>Price</th>
        <th></th>


    <?php foreach($products as $product):?>
        <tr>
        <td><?php echo $product['productCode']?></td>
        <td><?php echo $product['productName']?></td>
        <td><?php echo $product['listPrice']?></td>
        <td><form action="delete.php" method="post">
        <input type="hidden" name="product_id" value=<?php echo $product['productID']?>>
        <input type="submit" value="Delete">
        </form></td>
        </tr>
    <?php endforeach;?>
    </table>

    <h3><a id= "underlink"  href="addProduct.php">Add Product</a></h3>
    </main>
    <footer>
    <p id="bottom"> &copy; 2010 My Guitar Shop, Inc.</p>
    </footer>
    


